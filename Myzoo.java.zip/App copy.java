package coles;

import java.util.ArrayList;
import java.util.HashMap;

public class App {
    private ArrayList<Animal> animalsList;
    private HashMap<String, Integer> speciesCount;
// The private keyword in this case specifies the access level of species count in this case the variable is being
// restricted to the app class. Hashmap in this case is declaring the type of species count variable.
// In which indicates that species count is a hashmap that is a data structure in java that can store value pairs.
    public App() {
        animalsList = new ArrayList<>();
        speciesCount = new HashMap<>();
    }

    public void processArrivingAnimals(String[] names, int[] ages, String[] species) {
        for (int i = 0; i < names.length; i++) {
            Animal animal = new Animal(names[i], ages[i], species[i]);
            animalsList.add(animal);
            speciesCount.put(species[i], speciesCount.getOrDefault(species[i], 0) + 1);

            System.out.println("New animal arrived: " + names[i] + " (Age: " + ages[i] + ", Species: " + species[i] + ")");
        }
    }
        // This is a public method that starts with processArrivingAnimalsand takes three arrays as the parameters as names,
    //ages, and species. The arrays represent the names ages and species of the animals. Also ignitiating a loop that iterates
    //over the elemant of arrays names ages and species.
    public void generateReport() {
        System.out.println("\n Complete Animal Report");
        for (Animal animal : animalsList) {
            System.out.println("Name: " + animal.getName() + ", Age: " + animal.getAge() + ", Species: " + animal.getSpecies());
        }

        System.out.println("\n- Species Count -");
        for (String species : speciesCount.keySet()) {
            System.out.println(species + ": " + speciesCount.get(species));
        }
    }
             //The generate report within the app class is responsible for generating a report about the animals that have
    // arrived. The line starts a loop that iterates over animal object in the animalslist arraylist. Within the loop
    //this line prints information of each animal like name, age, and species and retrieves information such as getName,
    //getAge, getSpecies methods of the animal class.
    public static void main(String[] args) {
        String[] hyenaNames = {"Hanna", "Prine", "Berry", "Lola"};
        int[] hyenaAges = {7, 9, 4, 2};
        String[] hyenaSpecies = {"Hyena", "Hyena", "Hyena", "Hyena"};

        String[] lionNames = {"Garry", "Sandy"};
        int[] lionAges = {6, 7};
        String[] lionSpecies = {"Lion", "Lion"};

        String[] tigerNames = {"Dave", "Zara", "John"};
        int[] tigerAges = {3, 4, 5};
        String[] tigerSpecies = {"Tiger", "Tiger", "Tiger"};

        String[] bearNames = {"Jenny"}; int[] bearAges = {4}; String[] bearSpecies = {"Bear"};

        App app = new App();
        System.out.println("- New Zoo Hyenas");
        app.processArrivingAnimals(hyenaNames, hyenaAges, hyenaSpecies);
        System.out.println("\n- New Zoo Lions");
        app.processArrivingAnimals(lionNames, lionAges, lionSpecies);
        System.out.println("\n- New Zoo Tigers");
        app.processArrivingAnimals(tigerNames, tigerAges, tigerSpecies);
        System.out.println("\n- New Bear for Zoo");
        app.processArrivingAnimals(bearNames, bearAges, bearSpecies);

        System.out.println("\n Loading my Zoo Animal Report...");
        app.generateReport();
    }
}
//