package coles;

public class Animal {
    private String name;
    private int age;
    private String species;

    public Animal(String name, int age, String species) {
        this.name = name;
        this.age = age;
        this.species = species;
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }
}

class Hyena extends Animal {
    public Hyena(String name, int age) {
        super(name, age, "Hyena");
    }
}

class Lion extends Animal {
    public Lion(String name, int age) {
        super(name, age, "Lion");
    }
}

class Tiger extends Animal {
    public Tiger(String name, int age) {
        super(name, age, "Tiger");
    }
}

class Bear extends Animal {
    public Bear(String name, int age) {
        super(name, age, "Bear");
    }
}

